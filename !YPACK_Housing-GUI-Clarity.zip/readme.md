### Hi !

All my creations are possible to be used and/or modified in other creations provided three things:

- If you credit me with my nickname and the link of my creation
- If you share your creation with the same permissions as mine
- And if your creation is not to be commercial

Credit exemple:

```
Dark GUI by Yomna
https://www.planetminecraft.com/texture-pack/yomny-pack-housing-gui-clarity/
```